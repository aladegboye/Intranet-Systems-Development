<?php
ob_start();
session_start();
require_once 'dbconnect.php';

if( !isset($_SESSION['user']) ) {
    header("Location: index.php");
    exit;
}
$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PEER ASSESSMENT APP</title>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>
<header>
    <img id="Peer Assessment logo" src="peerassessmentlogo.jpg" alt="Peer Assessment App"/>
    <nav>
        <div id="quicklinks">
            <ul class = "horizontal">
                <li><a href ="#">PEER ASSESSMENT SYSTEM</a></li>
                <li><a href ="#">Admin Login</a></li>
                <li><a href ="#">Home</a></li> <li>
                    <a href="register.php">Sign Up</a></li><li><a href ="index.php">Login</a></li>
            </ul>
        </div>
    </nav>
    <img src="rgu-building.jpg" alt="Rgu Building" class="rguimage"/>
    <section>
        <h2>Robert Gordon University School of Computing Science and Digital Media</h2>
        <h3>Peer Assessment in Group Projects</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Vestibulum tempor sem ac blandit porta. Nam volutpat ac
            odio eu hendrerit. Mauris at vulputate metus. Aliquam sed
            commodo justo. Sed ut lacus dui. Proin quis nisl consequat,
            egestas sapien ut, laoreet orci. Nullam in magna nulla.
            Morbi viverra vitae velit a blandit. Phasellus pulvinar mi
            ac diam facilisis, nec mattis purus semper.</p>
    </section>
    <aside>
        <h3>News and Events</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Vestibulum tempor sem ac blandit porta. Nam volutpat ac
            odio eu hendrerit. Mauris at vulputate metus.</p>
    </aside>
    <footer>
        <h4>Copyright 2018 Adeoye Aladegboye</h4>
    </footer>
</header>
</body>
</html>
